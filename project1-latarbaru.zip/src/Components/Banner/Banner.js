// import React from 'react'
// import { Container, Col, Row } from 'react-bootstrap'
// import ImageBanner from '../../Assets/Images/latar01.jpeg'

// class BannerProduct extends React.Component {
//     render() {
//         return (
//             <Container fluid>
//                 <Row>
//                     <Col md="12" className="banner-style">
//                         <div className="image-style" style={{
//                             backgroundImage: `url(${ImageBanner})`
//                         }} >
//                         </div>
//                         <div className="box-text-banner position-absolute top-50 start-50 translate-middle">
//                             <div className="text-center">
//                                 <h1 className="art tittle-h1-banner">.</h1>
//                                 <h3 className="description-p-banner" >.</h3>
//                             </div>
//                         </div>
//                     </Col>
//                 </Row>
//             </Container>
//         )
//     }
// }

// export default BannerProduct

// // gadipakejuga