import React from 'react'
import { Col, Row, Container } from 'react-bootstrap'
import ImageBanner from '../../Assets/Images/product-3.jpg'

class Detailpage extends React.Component {
    render() {
        return (
            <Container fluid>
                <Row className="artic-style">
                    <Col md="8" className="box-left-articles">
                        <div className="image-article" style={{
                            backgroundImage: `url(${ImageBanner})`
                        }} >
                        </div>
                    </Col>
                    <Col md="4" className="text-article">
                        <h1>The Articles</h1>
                        <p>Integer eget neque tincidunt, dignissim libero fringilla, 
                           dictum ligula. Curabitur quis ligula quis augue accumsan convallis.
                           Integer sed nibh et dolor ornare mattis vel eu risus. 
                           Suspendisse malesuada ante eu consectetur ultrices.
                           Pellentesque commodo ex felis, non sodales ligula sodales id. 
                           Orci varius natoque penatibus et magnis dis parturient montes, 
                           nascetur ridiculus mus. In molestie euismod maximus. 
                           Cras mollis nisl vitae vulputate lacinia. 
                           Sed mattis fringilla nunc at lacinia. 
                           Quisque et quam ac erat faucibus scelerisque ut at erat. </p>
                    </Col>
                </Row>
            </Container>
        )
    }
}

export default Detailpage